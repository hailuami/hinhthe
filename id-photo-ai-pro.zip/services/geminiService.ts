
import { GoogleGenAI } from "@google/genai";
import { ProcessingOptions, Outfit, BackgroundColor, PhotoSize } from "../types";

const getApiKey = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey || apiKey === "undefined") {
    throw new Error("API Key chưa được cấu hình trên Vercel.");
  }
  return apiKey;
};

export const processIDPhoto = async (base64Image: string, options: ProcessingOptions): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  const cleanBase64 = base64Image.split(',')[1] || base64Image;

  let outfitDetail = '';
  switch (options.outfit) {
    case Outfit.VEST:
      outfitDetail = `mặc bộ đồ vest màu ${options.vestColor || 'đen'}, bên trong sơ mi trắng, thắt cà vạt chuyên nghiệp.`;
      break;
    case Outfit.WHITE_SHIRT:
      outfitDetail = `mặc áo sơ mi trắng có cổ màu ${options.shirtColor || 'trắng'} tinh khôi, cài cúc ngực ngay ngắn.`;
      break;
    case Outfit.AO_DAI:
      outfitDetail = `mặc Áo Dài truyền thống Việt Nam màu ${options.aoDaiColor || 'trắng'}, phong cách trang trọng.`;
      break;
    default:
      outfitDetail = `mặc trang phục ${options.outfit}`;
  }

  const prompt = `
    Bạn là một nhiếp ảnh gia chuyên nghiệp tại studio ảnh thẻ.
    HÃY TẠO ẢNH THẺ (ID PHOTO) TỪ ẢNH GỐC NÀY.
    
    YÊU CẦU BỐ CỤC:
    1. Chụp từ ngực trở lên (Portrait). Tuyệt đối không lấy toàn thân.
    2. Khuôn mặt ở chính giữa, nhìn thẳng vào ống kính.
    3. Hai vai cân bằng, không bị nghiêng.
    
    YÊU CẦU CHỈNH SỬA:
    - TRANG PHỤC: Thay đổi trang phục của người trong ảnh thành: ${outfitDetail}. Ghép khuôn mặt vào trang phục một cách tự nhiên nhất.
    - PHÔNG NỀN: Đổi nền thành màu ${options.bgColor === BackgroundColor.BLUE ? 'Xanh dương đậm chuyên nghiệp' : 'Trắng tinh khiết'}.
    - LÀM ĐẸP: ${options.smoothSkin ? 'Làm mịn da nhẹ nhàng,' : ''} ${options.removeBlemishes ? 'xóa mụn,' : ''} làm sáng khuôn mặt tự nhiên.
    - KÍCH THƯỚC: Tạo ảnh theo tỉ lệ chuẩn khổ ${options.size}.
    
    Hãy trả về bức ảnh sắc nét, chuyên nghiệp nhất như vừa chụp tại studio. Không trả về văn bản, chỉ trả về ảnh kết quả.
  `;

  return callGemini(ai, cleanBase64, prompt, options.size);
};

export const refineIDPhoto = async (base64Image: string, userRequest: string, size: PhotoSize): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  const cleanBase64 = base64Image.split(',')[1] || base64Image;

  const prompt = `
    Dựa trên ảnh thẻ hiện tại, hãy thực hiện chỉnh sửa theo yêu cầu sau của khách hàng: "${userRequest}".
    Lưu ý: 
    - Giữ nguyên bố cục ảnh thẻ chuyên nghiệp.
    - Giữ nguyên khuôn mặt và phông nền cũ trừ khi khách hàng yêu cầu thay đổi.
    - Chỉ thực hiện thay đổi nhỏ theo đúng yêu cầu.
    - Trả về kết quả là ảnh thẻ hoàn thiện. Không trả về văn bản.
  `;

  return callGemini(ai, cleanBase64, prompt, size);
};

const callGemini = async (ai: any, base64Data: string, prompt: string, size: PhotoSize): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { inlineData: { data: base64Data, mimeType: 'image/jpeg' } },
          { text: prompt },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: size === PhotoSize.SIZE_3X4 ? "3:4" : "4:3"
        }
      }
    });

    const candidate = response.candidates?.[0];
    if (!candidate) throw new Error("AI không phản hồi.");

    for (const part of candidate.content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    if (candidate.content.parts[0]?.text) {
      throw new Error("AI từ chối tạo ảnh: " + candidate.content.parts[0].text);
    }

    throw new Error("Không tìm thấy dữ liệu ảnh.");
  } catch (error: any) {
    console.error("Gemini Error:", error);
    throw new Error(error.message || "Lỗi xử lý AI.");
  }
};
